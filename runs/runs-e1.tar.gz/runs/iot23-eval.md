### CTU-Honeypot-Capture-4-1 (host 192.168.1.132)

Capture 2018-10-25T12:06:37Z – 2018-10-26T09:58:24Z; labelled flows from host 452, malicious 0


Quarant findings on host: I3_API_OVER_PLAINTEXT=4, I3_AUTH_TOKEN_IN_URL=8, I3_MANAGEMENT_API_EXPOSED=4, I4_I5_COMBINED_RISK=1, I5_KNOWN_VULNERABLE_COMPONENT=1, I6_HTTP_BASELINE_PROTOCOL_MISMATCH=7, I6_HTTP_BASELINE_UNEXPECTED_DOMAIN=3, I6_STORED_DATA_SIGNAL_OBSERVED=3, I8_UNREGISTERED_DEVICE_ACTIVE=1, INSECURE_HTTP=54, INSECURE_HTTP_AUTH=46, INSECURE_HTTP_TOKEN=8, PERIODIC_COMMUNICATION_OBSERVED=1, R1_COMPOSITE_RISK=2, R1_QUARANTINE_RECOMMENDATION=4

Behaviour findings toward destinations without malicious labels (review): PERIODIC_COMMUNICATION_OBSERVED dst=2.16.60.82:443

### CTU-Honeypot-Capture-5-1 (host 192.168.2.3)

Capture 2018-09-21T09:52:28Z – 2018-09-21T14:50:00Z; labelled flows from host 979, malicious 0


Quarant findings on host: I3_UNEXPECTED_CLOUD_ENDPOINT=4, I3_WEAK_ECOSYSTEM_CRYPTO_SIGNAL=1, I4_I5_COMBINED_RISK=1, I4_WEAK_UPDATE_VISIBILITY=1, I5_KNOWN_VULNERABLE_COMPONENT=1, I6_HTTP_BASELINE_PLAINTEXT=153, I6_HTTP_BASELINE_PROTOCOL_MISMATCH=1, I6_HTTP_BASELINE_UNEXPECTED_DOMAIN=1, I7_TLS_WEAK_CIPHER_OFFERED=8, I8_UNREGISTERED_DEVICE_ACTIVE=1, INSECURE_HTTP=157, PERIODIC_COMMUNICATION_OBSERVED=4, PERSISTENT_CONNECTION_ATTEMPTS=1, R1_COMPOSITE_RISK=3, R1_QUARANTINE_RECOMMENDATION=1

Behaviour findings toward destinations without malicious labels (review): PERIODIC_COMMUNICATION_OBSERVED dst=13.32.118.117:80; PERIODIC_COMMUNICATION_OBSERVED dst=176.32.98.203:80; PERIODIC_COMMUNICATION_OBSERVED dst=52.216.16.8:80; PERIODIC_COMMUNICATION_OBSERVED dst=54.239.31.37:443; PERSISTENT_CONNECTION_ATTEMPTS dst=93.184.216.34:80

### CTU-IoT-Malware-Capture-20-1 (host 192.168.100.103)

Capture 2018-10-02T11:12:49Z – 2018-10-03T11:11:49Z; labelled flows from host 3207, malicious 16

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| C&C-Torii | 16 (16) | 1 | tcp/443(16) | missed |  |  |

Quarant findings on host: I8_UNREGISTERED_DEVICE_ACTIVE=1

### CTU-IoT-Malware-Capture-21-1 (host 192.168.100.113)

Capture 2018-10-03T13:22:33Z – 2018-10-04T13:16:40Z; labelled flows from host 3284, malicious 14

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| C&C-Torii | 14 (14) | 1 | tcp/443(14) | missed |  |  |

Quarant findings on host: I8_UNREGISTERED_DEVICE_ACTIVE=1

### CTU-IoT-Malware-Capture-3-1 (host 192.168.2.5)

Capture 2018-05-19T18:57:19Z – 2018-05-21T07:04:46Z; labelled flows from host 154886, malicious 151566

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| Attack | 5961 (5961) | 221 | tcp/22(5961) | detected | PERSISTENT_CONNECTION_ATTEMPTS=75 |  |
| C&C | 8 (8) | 5 | tcp/2407(8) | missed |  |  |
| PartOfAHorizontalPortScan | 145597 (145597) | 61766 | tcp/22(122302) tcp/59353(23295) | detected | OUTBOUND_SCAN_SUSPECTED=1 |  |

Quarant findings on host: I8_UNREGISTERED_DEVICE_ACTIVE=1, OUTBOUND_SCAN_SUSPECTED=1, PERIODIC_COMMUNICATION_OBSERVED=1, PERSISTENT_CONNECTION_ATTEMPTS=77

Behaviour findings toward destinations without malicious labels (review): PERSISTENT_CONNECTION_ATTEMPTS dst=31.43.155.196:22

### CTU-IoT-Malware-Capture-34-1 (host 192.168.1.195)

Capture 2018-12-21T14:50:16Z – 2018-12-22T14:50:13Z; labelled flows from host 23144, malicious 21222

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| C&C | 6706 (6706) | 1 | tcp/6667(6706) | detected | PERSISTENT_CONNECTION_ATTEMPTS=1 |  |
| DDoS | 14394 (14393) | 3 | tcp/80(14393) udp/5376(1) | no_detector |  | Quarant has no detector for this class yet |
| PartOfAHorizontalPortScan | 122 (121) | 2 | tcp/63798(121) udp/256(1) | missed |  |  |

Quarant findings on host: I4_WEAK_UPDATE_VISIBILITY=1, I8_UNREGISTERED_DEVICE_ACTIVE=1, INSECURE_HTTP=12, PERSISTENT_CONNECTION_ATTEMPTS=5

Behaviour findings toward destinations without malicious labels (review): PERSISTENT_CONNECTION_ATTEMPTS dst=50.50.50.53:53

### CTU-IoT-Malware-Capture-42-1 (host 192.168.1.197)

Capture 2019-01-10T13:34:47Z – 2019-01-10T21:55:30Z; labelled flows from host 4421, malicious 6

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| C&C-FileDownload | 3 (3) | 1 | tcp/80(3) | missed |  |  |
| FileDownload | 3 (3) | 1 | tcp/80(3) | no_detector |  | Quarant has no detector for this class yet |

Quarant findings on host: I4_WEAK_UPDATE_VISIBILITY=1, I8_UNREGISTERED_DEVICE_ACTIVE=1, INSECURE_HTTP=33, PERSISTENT_CONNECTION_ATTEMPTS=1

Behaviour findings toward destinations without malicious labels (review): PERSISTENT_CONNECTION_ATTEMPTS dst=185.244.25.183:4975

### CTU-IoT-Malware-Capture-8-1 (host 192.168.100.113)

Capture 2018-07-31T13:15:11Z – 2018-08-01T13:15:06Z; labelled flows from host 10401, malicious 8222

| Label | Flows (TCP) | Destinations | Top ports | Outcome | Matched | Note |
|---|---|---|---|---|---|---|
| C&C | 8222 (8222) | 2 | tcp/50(8222) | detected | PERSISTENT_CONNECTION_ATTEMPTS=2 |  |

Quarant findings on host: I8_UNREGISTERED_DEVICE_ACTIVE=2, PERSISTENT_CONNECTION_ATTEMPTS=2

