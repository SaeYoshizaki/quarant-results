# What Quarant can currently observe/derive passively (event types / inventory fields)
Identity: inventory mac_address, mac_vendor(OUI, reference), hostname (DHCP/mDNS), dhcp_vendor_class, dhcp_param_request_list, mdns_*, ssdp_server/location, dns_queries, observed_ports/protocols per device.
Plaintext/credentials: INSECURE_HTTP, INSECURE_HTTP_AUTH, INSECURE_HTTP_COOKIE, INSECURE_HTTP_TOKEN, INSECURE_HTTP_BODY_SECRET, INSECURE_MQTT, INSECURE_MQTT_CREDENTIALS, INSECURE_MQTT_PAYLOAD_SECRET, INSECURE_TELNET, INSECURE_TELNET_CREDENTIALS, I3_AUTH_TOKEN_IN_URL, I3_API_OVER_PLAINTEXT.
TLS: TLS_CLIENT_HELLO (version, ciphers, SNI, JA3), I7_TLS_WEAK_VERSION_OBSERVED, I7_TLS_WEAK_CIPHER_OFFERED/SELECTED/SUITE_OBSERVED, I7_TLS_ONLY_LEGACY_CIPHERS_OFFERED, I7_TLS_CERTIFICATE_ANOMALY_OBSERVED (self-signed/expired/SNI mismatch; TLS<=1.2 only).
Services/exposure: I2_*_SERVICE_OBSERVED / I2_*_PROTOCOL_EVIDENCE (telnet, ftp, rtsp, mqtt, coap answered), I2_INSECURE_SERVICE_TO_PUBLIC_NETWORK, I2_HTTP_ADMIN_INTERFACE_SUSPECTED, I3_MANAGEMENT_API_EXPOSED, I9_SETUP_ENDPOINT_STILL_ACTIVE.
Updates: I4_FIRMWARE_UPDATE_OBSERVED, I4_INSECURE_FIRMWARE_UPDATE_HTTP, I4_SUSPICIOUS_UPDATE_SOURCE, I4_WEAK_UPDATE_VISIBILITY, I4_MAYBE/LIKELY_EOL_DEVICE.
Knowledge DB (reference): I5_KNOWN_VULNERABLE_COMPONENT, I4_I5_COMBINED_RISK, I3_UNEXPECTED_CLOUD_ENDPOINT.
Privacy: I6_* (PII in plaintext HTTP, unexpected destinations/SNI vs category baseline).
Behaviour: OUTBOUND_SCAN_SUSPECTED, PORT_SCAN_SUSPECTED, LATERAL_SCAN_SUSPECTED, PERIODIC_COMMUNICATION_OBSERVED, PERSISTENT_CONNECTION_ATTEMPTS (reconnect loops, e.g. when cloud unreachable), IP_MAC_BINDING_CHANGED.
Not implemented (could be added passively): NTP/time sync observation, DNS-over-HTTPS detection, QUIC, certificate chain/issuer checks, update-traffic signature presence, data volume baselines.
